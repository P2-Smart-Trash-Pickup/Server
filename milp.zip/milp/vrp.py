from PIL import Image, ImageDraw

from gen_data import gen_data_or, generate_distance_matrix
from test_vrp import make_test
from vrp_clark_wright import draw_clark_wright, solve_vrp_clark_wright
from vrp_milp import draw_milp, solve_vrp_milp
from vrp_or import solve_vrp_google
from vrp_tabu import solve_vrp_tabu
import time

point_amount = 500 
width = 1920
height = 1080
vehicle_amount = 2

points, distance_matrix = generate_distance_matrix(point_amount, width, height)
img = Image.new("RGB", (width, height))
draw = ImageDraw.Draw(img)

for point in points:
    draw.circle([point[0], point[1]], 10)

demand = [0]
for _ in range(point_amount - 1):
    demand.append(1)

img = Image.new("RGB", (width, height))
draw = ImageDraw.Draw(img)

for point in points:
    draw.circle([point[0], point[1]], 10)

#make_test(2,1,15)

"""
routes, cw_distance = solve_vrp_clark_wright(
    distance_matrix, demand, round(point_amount / 2) + 1
)
print(routes)

print(f"CW: {cw_distance}")

draw_clark_wright(points, routes, draw)

img.save("cw.png")

"""
img = Image.new("RGB", (width, height))
draw = ImageDraw.Draw(img)
i = 0
for point in points:
    draw.circle([point[0],point[1]],10)
    draw.text((point[0],point[1]),str(i),anchor="mm")
    i += 1
tabu_start = time.time()
routes, tabu_distance = solve_vrp_tabu(distance_matrix, demand,round(point_amount / 2) + 1, 10, 10)
tabu_duration = time.time() - tabu_start

print(f"TABU distance: {tabu_distance}")
print(f"TABU duration: {tabu_duration}")

draw_clark_wright(points,routes,draw)

img.save("tabu.png")

"""
img = Image.new("RGB", (width, height))
draw = ImageDraw.Draw(img)
i = 0
for point in points:
    draw.circle([point[0],point[1]],10)
    draw.text((point[0],point[1]),str(i),anchor="mm")
    i += 1

prob,milp_distance,x,vehicles = solve_vrp_milp(distance_matrix,demand,vehicle_amount,round(point_amount/2)+1)

print(f"MILP: {milp_distance}")

draw_milp(distance_matrix=distance_matrix,points=points,x=x,vehicles=vehicles,vehicle_amount=vehicle_amount,draw=draw)
img.save("milp.png")
"""

img = Image.new("RGB",(width,height))
draw = ImageDraw.Draw(img)
i = 0
for point in points:
    draw.circle([point[0],point[1]],10)
    draw.text((point[0],point[1]),str(i),anchor="mm")
    i += 1
data = gen_data_or(distance_matrix,point_amount,vehicle_amount,demand)

or_start = time.time()
or_distance = solve_vrp_google(data,points,draw)
or_duration = time.time() - or_start

print(f"OR distance: {or_distance}")
print(f"OR duration: {or_duration}")
img.save("OR.png")
