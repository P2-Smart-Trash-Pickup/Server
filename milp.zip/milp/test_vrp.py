import time
from gen_data import generate_distance_matrix,gen_data_or
from vrp_milp import solve_vrp_milp 
from vrp_clark_wright import solve_vrp_clark_wright
from vrp_or import solve_vrp_google
from vrp_tabu import solve_vrp_tabu
def make_test(vehicle_amount,step,times):
    for i in range(1,times,step):
        milp_total_duration = 0
        milp_distance_total = 0

        c_w_total_duration = 0
        c_w_distance_total = 0

        or_total_duration = 0
        or_distance_total = 0

        tabu_total_duration = 0
        tabu_distance_total = 0

        difference_procent = 0
        print(f"{i+3} points")
        for _ in range(10):
            _,distance_matrix = generate_distance_matrix(i+3,500,500)
            vehicle_capacity = (i+3)*2 

            demand = [0]

            for _ in range(1,i+3):
                demand.append(1)

            data = gen_data_or(distance_matrix,len(distance_matrix),vehicle_amount,demand)

            or_start = time.time()
            or_distance = solve_vrp_google(data,1,1)
            or_duration = time.time() - or_start
                
            c_w_start = time.time()
            _,c_w_distance = solve_vrp_clark_wright(distance_matrix,demand,vehicle_capacity)
            c_w_duration = time.time() - c_w_start

            milp_start = time.time()
            _,milp_distance,_,_ = solve_vrp_milp(distance_matrix,demand,vehicle_amount,vehicle_capacity)
            milp_duration = time.time() - milp_start

            tabu_start = time.time()
            _,tabu_distance = solve_vrp_tabu(distance_matrix,demand,vehicle_capacity,1000,100)
            tabu_duration = time.time() - tabu_start

            difference_procent += (c_w_distance - milp_distance) / milp_distance

            milp_total_duration += milp_duration 
            c_w_total_duration += c_w_duration 
            or_total_duration += or_duration

            milp_distance_total += milp_distance
            c_w_distance_total += c_w_distance
            or_distance_total += or_distance

            tabu_total_duration += tabu_duration
            tabu_distance_total += tabu_distance

        milp_total_duration= milp_total_duration/ 10
        c_w_total_duration= c_w_total_duration/ 10
        difference_procent = difference_procent / 10

        milp_distance_total = milp_distance_total / 10
        c_w_distance_total = c_w_distance_total / 10

        or_total_duration = or_total_duration / 10
        or_distance_total = or_distance_total / 10

        tabu_total_duration = tabu_total_duration/ 10
        tabu_distance_total = tabu_distance_total/ 10

        print(f"Milp distance: {milp_distance_total}")
        print(f"CW distance: {c_w_distance_total}")
        print(f"OR distance: {or_distance_total}")
        print(f"TABU distance: {tabu_distance_total}")
        #print(f"Procentwise difference: {difference_procent}%")
        print("")
        print(f"MILP took {"%.2f" % milp_total_duration}s")
        print(f"CW took {"%.2f" % c_w_total_duration}s")
        print(f"OR took {"%.2f" % or_total_duration}s")
        print(f"TABU took {"%.2f" % tabu_total_duration}s")
        print("")
